

#include <iostream>
#include <string>
#include <cctype>
using namespace std;


bool isValidUppercaseStateCode(string stateCode) // ensures statecode is valid
{
    const string codes =
    "AL.AK.AZ.AR.CA.CO.CT.DE.DC.FL.GA.HI.ID.IL.IN.IA.KS."
    "KY.LA.ME.MD.MA.MI.MN.MS.MO.MT.NE.NV.NH.NJ.NM.NY.NC."
    "ND.OH.OK.OR.PA.RI.SC.SD.TN.TX.UT.VT.VA.WA.WV.WI.WY";
    return (stateCode.size() == 2  &&
            stateCode.find('.') == string::npos  &&  // no '.' in stateCode
            codes.find(stateCode) != string::npos);  // match found
}



bool hasCorrectSyntax(string pollData)
{
    int k = 0;
    string t;
    for (size_t i = 0; i != pollData.size(); i++) // makes everything uppercase
        t += toupper(pollData[i]);
    
    while (k != pollData.size())
    {
        if (isValidUppercaseStateCode(t.substr(k, 2)) && // if statecode (which is assumed to be the first two characters) is valid
            (isdigit(pollData[k+2])) && // this accounts for single digit number of voters
            (isalpha(pollData[k+3])))
            k = k+4; // should begin the loop again at the next statecode
        else if (isValidUppercaseStateCode(t.substr(k, 2)) && // if statecode is valid
                 (isdigit(pollData[k+2])) && //this accounts for doubledigit number of voters
                 (isdigit(pollData[k+3])) &&
                 (isalpha(pollData[k+4])))
            k = k+5; // should begin the loop again at the next statecode
        else return false;
    }
    return true;
    
}

int countVotes(string pollData, char party, int& voteCount)
{
    int k = 0; // string position
    int l =0; // temporary substitute for voteCount
    string t;
    for (size_t i = 0; i != pollData.size(); i++)
        t += toupper(pollData[i]); //making sure string is uppercase
    party = toupper(party); //making sure party is uppercase
    
    while (k!= t.size())
    {
        if (hasCorrectSyntax(pollData)) // check to make sure everything has correct syntax
        {
            if (isalpha(party)) // if party is valid
            {
                if (isalpha(t[k+3]) && party == t[k+3]) // if party is equal to partycode at end of state forecast
                {
                    char num = t[k+2]; // converting number of voters to integer
                    l = l + (num -'0');
                    k = k+4;
                    if (l == 0)
                        return 2;
                }
                
                else if (isdigit(t[k+3]) && party == t[k+4])// if party is equal to partycode at end of state forecast, accounting for double digits
                    
                {
                    char tens = t[k+2]; // converting number of voters to integer if number of voters
                    char ones = t[k+3]; // is a double digit
                    int num = ((tens-'0') * 10) + (ones -'0');
                    l = l + (num);
                    k = k+5;
                    if (l == 0)
                        return 2;
                }
                else return 2;
            }
            else return 3;
        }
        else return 1;
    }
    voteCount = l;
    
    return 0;
}





int main()
{
    int count = 0;
    string poll_data;
    cout << "Enter poll data string: ";
    getline (cin, poll_data);
    countVotes(poll_data, 'r', count);
    if (hasCorrectSyntax(poll_data))
        cout << "Congrats! The syntax is still correct!" << endl;
    else
        cout << "You've messed up somewhere." << endl;
    cout << "Your votecount is " << count << ". Or is it?" << endl;
    if (countVotes(poll_data, 'r', count)== 0)
        cout << "CountVotes is equal to 0." << endl;
    else if (countVotes(poll_data, 'r', count)== 1)
        cout << "CountVotes is equal to 1." << endl;
    else if (countVotes(poll_data, 'r', count)== 2)
        cout << "CountVotes is equal to 2." << endl;
    else if (countVotes(poll_data, 'r', count)== 3)
        cout << "CountVotes is equal to 3." << endl;
}
