#include <iostream>
#include <string>
#include <cctype>
using namespace std;

int appendToAll(string a[], int n, string value)
{
    if (n < 0)
        return -1;
    for (int i =0; i < n; i++) //runs through array
        a[i] += value;          // appends value to each element in array
    return n;
}

int lookup(const string a[], int n, string target)
{
    int i = 0;
    while (i < n)
    {
        if ((a[i]) == target) //if element is equal to character, return position
            return i;
        else
            i++; // if not, run through the entire array
    }
    return -1;
}

int positionOfMax(const string a[], int n)
{
    int i = 0;
    int j = 0; //j is equal to maximum position
    if (n == 0 || n < 0)
        return -1;
    while ((i+1) != n)
    {
        if (a[j] < a[i+1] ) //if the element in position j is less than the one to the right of it
        {
            j = i+1; //check the element next to it with the element right of this
            i++;
        }
        else if (a[j] > a[i+1]) //if element in position j is greater than the one in position j+1
        {
            i++; //compare element in position j with element one over repeatedly
        }
        else if (a[j] == a[i+1]) //accounts for more than one 'maxiumum' element
            return j;
    }
    return j;
}

int rotateLeft(string a[], int n, int pos)
{
    
    string i = a[n-1]; // makes backup of current element in last position of array
    a[n-1] = a[pos]; // insert a[pos] in last position
    for (int j = 0; (pos+j)!=n-1 ; j++)
    {
        a[pos+j] = a[pos+j+1]; // move elements over to the left
    }
    a[n-2] = i; //insert previous 'last element' into second-to-last position
    return pos;
    
}

int countRuns(const string a[], int n)
{
    if (n < 0)
        return -1;
    int runs = 0; //keeps track of number of sequences
    int i = 0;
    while (i!= n) //runs through positions in array
    {
        if (a[i] != a[i+1])
        {
            runs++; //increments runs when a new sequence is started
            i++;
        }
        else if (a[i] == a[i+1]) //compare
            i++;
    }
    return runs;
}

int flip(string a[], int n)
{
    string i;
    int j = 1;
    while (j <= (n/2)) // does not need to make switches for every character
    {   i = a[n-j]; //makes backup of element in position n-j
        a[n-j] = a[j-1]; //inserts new element in previous position
        a[j-1] = i; //inserts old element in position of previous element
        j++;
    }
    return n;
}

int differ(const string a1[], int n1, const string a2[], int n2)
{
    int n =0;
    while (n!= n1 && n!=n2 )//runs through both arrays as long as both arrays still have elements
    {
        if (a1[n]==a2[n]) //increments, since elements that are equal don't matter to us
            n++;
        if (a1[n]!= a2[n]) //returns first element that doesn't match
            return n;
    }
    return n;
    
}

int subsequence(const string a1[], int n1, const string a2[], int n2)
{
    int n = 0; //position of element in a1
    int i = 0; //position of element in a2
    while (n != n1) //runs through array a1
    {
        if (a1[n]!=a2[i])
        {
            if (i>0)        //reset i to zero to compare a1[n] with beginning of a2
                i=0;
            else
                n++;
        }
        else if (a1[n]==a2[i])
        {
            n++;
            i++; //start going through a2
            if (i == n2) // if all elements in n2 have been run through, a1 contains a2
                return n - n2; //n = position at end of a2, so subtract length of a2 for beginning position
            
        }
    }
    return -1;
    
}


int lookupAny(const string a1[], int n1, const string a2[], int n2)
{
    int n =0;
    int i =0;
    while (n < n1) //runs through array a1
    {
        i=0; //position of element in array a2
        while (i <n2)
        {
            if (a1[n]==a2[i])
                return n;
            else if (a1[n]!=a2[i]) //check all elements in a2 with one element in a1
                i++;
            
        }
        n++;
    }
    return -1;
    
}



int separate(string a[], int n, string separator)
{
    string i;
    int k =0;
    int j = 1;
    
    if (n%2 ==0)
    {
        while (k <= (n/2)-1)
        {
            if (a[k] < separator)
                k++;
            else if (a[k] >= separator)
            {
                i = a[n-j]; // make backup of thing to be replaced
                a[n-j] = a[k]; //if a[k]
                a[k] = i;
                j++; // once elements are switched, change position
                if (a[k] <= separator)
                    k++; //move on
            }
        }
    }
    else if (n%2 !=0)// same as above, if n is an odd number.
    {
        while (k <= (n/2))
        {
            if (a[k] < separator)
                k++;
            else if (a[k] > separator)
            {
                i = a[n-j];
                a[n-j] = a[k];
                a[k] = i;
                j++;
                if (a[k] <= separator)
                    k++;
            }
        }
    }
    
    
    for (int m = 0; m < n-1; m++)//run through array to find first element greater than separator
    {
        if (a[m] <= separator)
            m++;
        else if (a[m] > separator)
            return m;
    }
    return -1;
}


int main()
{
    string people[5] = { "hillary", "gary", "donald", "jill", "evan" };
    int j = appendToAll(people, 5, "!!!");
    cout << j << endl;
    cout << people[0] << endl;
}
