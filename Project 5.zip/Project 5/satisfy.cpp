#include <iostream>
#include <string>
#include <cstring>

using namespace std;

const int MAX_WORD_LENGTH = 20;


int normalizeRules(char word1[][MAX_WORD_LENGTH+1],
                   char word2[][MAX_WORD_LENGTH+1],
                   int distance[],
                   int nRules)
{
    if (nRules <=0)//check if nRules is valid
        return 0;
    
    for (int j=0; j <nRules; j++) // make every character lowercase
    {
        for (int i=0; i<strlen(word1[j]);i++)
            word1[j][i] = tolower (word1[j][i]);
        for (int i=0; i<strlen(word2[j]);i++)
            word2[j][i] = tolower (word2[j][i]);
    }
    
    int one = 0;
    while(one < nRules) // if word in array 1 is same as word in array 2, make sure the word is in array 1
    {
        int cmp2 = 0;
        while (cmp2 < nRules)
        {
            if (strcmp(word1[one], word2[cmp2]) != 0)
                cmp2++;
            
            else if (strcmp(word1[one], word2[cmp2])==0)
            {
                strcpy(word2[cmp2], word1[cmp2]); //switch elements in word1 and word2
                strcpy(word1[cmp2], word1[one]);
                cmp2++;
                
            }
        }
        one++;
    }
    
    
    int first =0;
    while(first < nRules) //accounts for if word1 and word2 are the same in different elements
    {
        int compare = first+1;
        while (compare < nRules)
        {
            if (strcmp(word1[first], word1[compare])!=0)
                compare++;
            
            else if (strcmp(word1[first], word1[compare])==0 && strcmp(word2[first],word2[compare])==0)
            {
                if (distance[first] <= distance[compare]) //if rule is the same, the greatest distance is
                    distance[first] = distance[compare];    //carried into first instance and all others
                distance[compare] = 0;                      // receive distance 0
                compare++;
            }
            else
                compare++;
            
        }
        first++;
    }
    
    int row = 0;
    int branch = 0;
    int tracker =0;
    int counter = nRules;
    
    while (tracker < nRules) // tracker keeps track of # of cstrings that loop has gone through
    {
        int alpha = 0;
        int alpha2 =0;
        int nonalpha = 0;
        int nonalpha2=0;
        
        if (branch == 1) //if rule moves position, then checks new rule in old position
            row--;
        
        for(int length = 0; length != strlen(word1[row]); length++)
        {
            if (isalpha(word1[row][length]))
                alpha++; // count up alphabetical characters
            else
                nonalpha++;
        }
        for(int length2 = 0; length2 != strlen(word2[row]); length2++)
        {
            if (isalpha(word2[row][length2]))
                alpha2++; // count up alphabetical characters
            else
                nonalpha2++; // count up nonalphabetical characters
        }
        
        if (alpha==0) // accounts for empty strings
            nonalpha++;
        if (alpha2==0)
            nonalpha++;
        
        if (nonalpha != 0|| nonalpha2 !=0|| distance[row]<=0) // moves rules
        {
            for (int i = row; i < nRules; i++)
            {   strcpy(word1[i], word1[i+1]);
                strcpy(word2[i], word2[i+1]);
                distance[i] = distance[i+1];
                
            }
            tracker++;
            counter--;//keeps track of how many rules have been taken out
        }
        else
        {
            tracker++;
            row++;
        }
    }
    
    return counter;
}


int calculateSatisfaction(const char word1[][MAX_WORD_LENGTH+1],
                          const char word2[][MAX_WORD_LENGTH+1],
                          const int distance[],
                          int nRules,
                          const char document[])
{
    
    char copy[nRules][MAX_WORD_LENGTH+1];
    char copy2[nRules][MAX_WORD_LENGTH+1];
    int discopy[nRules];
    char draft[201];
    
    for (int i =0; i<nRules; i++) //copy word1 into array copy
        strcpy(copy[i], word1[i]);
    
    for (int i =0; i<nRules; i++) //copy word2 into array copy2
        strcpy(copy2[i], word2[i]);
    
    for (int i =0 ; i<nRules; i++)// copy distance into array discopy
        discopy[i]=distance[i];
    strcpy(draft, document);
    
    for (int i=0; i<=strlen(draft); i++) //lowercase everything
        draft[i] = tolower(draft[i]);
    
    int charcount =0; //copying the draft
    int tracker = 0;
    
    while (tracker < strlen(draft))
    {
        
        if (isalpha(draft[charcount]))
            charcount++;
        else if(draft[charcount] == ' ')
            charcount++;
        else
        {
            int looper = tracker;
            for (int i = charcount; looper < strlen(draft); i++)
            {
                draft[i] = draft[i+1];
                looper++;
            }
        }
        tracker++;
    }
    
    draft[charcount]='\0'; //
    
    
    int validRule = normalizeRules(copy, copy2, discopy, nRules); //the point of no return
    
    int satisfy = 0;
    
    int word = 0;
    int chara = 0;
    int letter =0;
    
    while (word < validRule)
    {
        
        while (letter < strlen(draft))
        {
            if (copy[word][chara] != draft[letter])
            {
                if (chara>0) //reset i to zero to compare draft[letter] with beginning of word1 in rule
                    chara =0;
                else
                {
                    int i = letter;
                    while (draft[i] != ' ' && i+1 < strlen(draft)) //moves to the beginning of next word
                        i++;                                        // by searching for space
                    letter = i+1;
                }
            }
            else if (copy[word][chara] == draft[letter]) //repeatedly adds chara and letters if
            {                                             //they are the same
                chara++;
                letter++;
            }
            
            if (chara ==strlen(copy[word])-1) //if word has been successfully found
            {
                int k=0;
                int letter2;
                int i = letter;
                
                while (k < discopy[word]) //then check for word 2
                {
                    int chara2 =0;
                    while (draft[i] != ' ' && i+1 < strlen(draft)) //move to beginning of next word
                        i++;                                        // do this distance-1 times
                    letter2 = i+1;
                    
                    if (draft[letter2] != copy2[word][letter2])
                        k++;
                    
                    
                    while (copy2[word][chara2] == draft[letter2])//repeatedly adds char and letters if same
                    {
                        chara2++;
                        letter2++;
                    }
                    if (chara2 == strlen(copy2[word]))// if word 2 has been successfully found
                    {
                        satisfy++; //rule is satisfied
                        break;
                    }
                    
                    k++;
                }
                
                int m=0;
                int n = letter;
                
                
                while (m < discopy[word])
                {
                    int chara2 =0;
                    while (draft[n] != ' ' && n >=0) //move to the beginning of last word
                        n--;                        //essentially the same as above except backwards
                    letter2 = n+1;
                    
                    if (draft[letter2] != copy2[word][letter2])
                        n++;
                    
                    
                    while (copy2[word][chara2] == draft[letter2])
                    {
                        chara2++;
                        letter2++;
                    }
                    if (chara2 == strlen(copy2[word]))
                    {
                        satisfy++;
                        break;
                    }
                    
                    m++;
                }

                
                
            }
            else break;
            
        }
        
        word++;
    }
    return satisfy;
}


int main()
{
    const char test[20][MAX_WORD_LENGTH+1] = { "mad", "deranged", "NEFARIOUS", "half-witted", "robot", "plot", "have"};
    const char test1[20][MAX_WORD_LENGTH+1] = { "scientist", "robot", "PLOT", "assistant", "deranged", "Nefarious", "mad"};
    int testfar[] = { 2, 4, 1, 3, 2, 1, 13};
    const char document[] = "The mad scientist took over the world.  He had a nefarious plot.";
    int k = calculateSatisfaction(test,test1, testfar, 7, document);
    cout << k<< endl;
    
}



